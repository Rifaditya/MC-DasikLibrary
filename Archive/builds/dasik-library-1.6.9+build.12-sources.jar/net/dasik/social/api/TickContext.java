/*
 * Zenith Sovereign Engineering - Dasik Library
 * Verified against: TickContext.java (Snapshot 10)
 */
package net.dasik.social.api;

import net.minecraft.util.RandomSource;

/**
 * Provides world-specific context for a single logic tick.
 */
public interface TickContext {
    public SocialEntity entity();

    public long gameTime();

    public float partialTick();

    public RandomSource random();
}

